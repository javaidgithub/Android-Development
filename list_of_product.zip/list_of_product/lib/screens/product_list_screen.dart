import 'package:flutter/material.dart';
import '../models/product_model.dart';
import '../widgets/product_tile.dart';
import 'product_detail_screen.dart';

class ProductListScreen extends StatelessWidget {
  final List<Product> products = [
    Product(
      title: 'Lenovo Ideapad 3 15IAU7',
      description: 'Intel Core i3 12th Gen 3.3 / 4.4 Ghz, 15.6" Screen, 4 GB RAM, 256 GB SSD, Intel Integrated Graphics, DOS, 3.59 lbs',
      price: 550.00,
      imageUrl: 'https://static3.webx.pk/files/35368/Images/l3-35368-1948519-060124022526704.jpg',
    ),
    Product(
      title: 'Dell Vostro - 3520',
      description: 'Intel Core i3 12th Gen 3.3 / 4.4 Ghz, 15.6" Screen, 8 GB RAM, 512 GB SSD, Intel Integrated Graphics, DOS, 3.65 lbs',
      price: 980.00,
      imageUrl: 'https://static3.webx.pk/files/4012/Images/dell-vostro-3520-laptop-4012-1917712-201123010734460.jpg',
    ),
    Product(
      title: 'HP Notebook 15 - 250 G10 i3',
      description: 'Intel Core i3 13th Gen 3.3 / 4.5 Ghz, 15.6" Screen, 4 GB RAM, 256 GB SSD, Intel Integrated Graphics, DOS, 3.35 Ibs',
      price: 880.00,
      imageUrl: 'https://m.media-amazon.com/images/I/61zRDADh+YS._AC_SL1500_.jpg',
    ),
    Product(
      title: 'Asus ExpertBook - B1502CB : 1Y',
      description: 'Intel Core i5 12th Gen 3.3 / 4.4 Ghz, 15.6" Screen, 8 GB RAM, 512 GB SSD, Fingerprint, Backlit, Intel Integrated Graphics, DOS, 3.73 lbs',
      price: 1000.00,
      imageUrl: 'https://media.istockphoto.com/id/519518538/photo/windows-8-1-on-hp-pavilion-ultrabook.jpg?s=1024x1024&w=is&k=20&c=fw0FXNH8EibHHk8aPCBUl_To3h178jZdwqexOQhmiEE=',
    ),
    Product(
      title: 'HP Notebook 15 - FD0336nia',
      description: 'Intel Core i3 13th Gen 3.3 / 4.5 Ghz, 15.6" Screen, 4 GB RAM, 256 GB SSD, Backlit, Intel Integrated Graphics, DOS, 3.5 Ibs',
      price: 1100.00,
      imageUrl: 'https://www.shutterstock.com/shutterstock/photos/1923641213/display_1500/stock-photo-modern-laptop-computer-with-a-blank-screen-on-the-desk-1923641213.jpg',
    ),
    Product(
      title: 'HP Notebook 15 - 250 G9 i5',
      description: 'Intel Core i5 12th Gen 3.3 / 4.4 Ghz, 15.6" Screen, 16 GB RAM, 512 GB SSD, Backlit, Intel Integrated Graphics, Windows 11 Home, 3.8 Ibs',
      price: 1250.00,
      imageUrl: 'https://www.shutterstock.com/shutterstock/photos/2126914553/display_1500/stock-photo-bangkok-thailand-hp-launch-new-notebook-laptop-hp-pavilion-laptop-eg-tu-on-february-2126914553.jpg',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Product List'),
        backgroundColor: Colors.blue,
      ),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          Color tileColor = index % 2 == 0 ? Colors.blue.shade50 : Colors.green.shade50;

          return ProductTile(
            product: products[index],
            backgroundColor: tileColor, // Pass color to ProductTile
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ProductDetailScreen(product: products[index]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
